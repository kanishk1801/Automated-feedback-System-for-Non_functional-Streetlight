package com.example.samadhan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Technician_home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_technician_home);
    }
}