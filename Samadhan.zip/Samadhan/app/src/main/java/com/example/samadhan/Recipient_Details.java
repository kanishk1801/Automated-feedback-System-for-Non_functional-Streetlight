package com.example.samadhan;

public class Recipient_Details {
    String name,number,password;
}
